# Cala's Pokecom BASIC 正式リリース手順書

> **この文書を正式リリース手順の正本（source of truth）とする。**
>
> 今後、Cala's Pokecom BASIC の正式リリースを行うときは、最初に本書を確認する。
> Version固有の release checklist / release notes は本書を補足する資料であり、手順が競合する場合は本書を優先する。
>
> 初版: 2026-09-29 / 公開実務の具体化: 2026-10-05

共通原則は[root rules.md](../../rules.md)と[IMPLEMENTATION_GUIDELINES](../development/IMPLEMENTATION_GUIDELINES.md)。本書はartifact / private→public / tag / Release / SHA256 / 公開後検証を担当し、一般実装規約を重複定義しません。

## 1. 対象リポジトリ

- 開発用 private: `CalaMaclir/RetroMiniBASIC-PicoCalc`
- 公開用 public: `CalaMaclir/Cala-s-Pokecom-BASIC`

開発用リポジトリを、実装・CI・実機確認・正式リリース候補の技術的な正本とする。
公開用リポジトリには、開発用で確認済みの source / documentation / GitHub Release を反映する。

## 2. リリース開始条件

正式リリース作業に入る前に、次を満たす。

- 対象Versionの実装範囲が確定している。
- 対象branch / PRの変更内容が整理されている。
- release blocker が残っていない。
- 必要な実機確認が完了している。
- README、manual、release notes が対象Versionに更新されている。
- PDFが最新Markdownから再生成されている。
- GitHub Actions の build / test が SUCCESS である。

Version固有の確認項目は `docs/release/v<version>-release-checklist.md` を作成して記録する。

## 3. 正式リリース元の確定

1. 対象Versionの開発branch / PRを最終確認する。
2. CI SUCCESS と実機 PASS を確認する。
3. 正式リリースするsourceを development repository の `main` に統合する。
4. 正式リリース元の development commit SHA を記録する。
5. そのcommitに対応する成功済み GitHub Actions run を正式な build provenance とする。

### CIの扱い

- 通常push/PRは詳細ホスト時間比較を省略（performance mode: off）。FAST/FULLとは独立する。
- 性能変更時とリリース候補ではreportを明示選択し、rawと警告をレビューする。
  Run workflowの`performance_mode: report`、または対象PRの`performance-report`ラベルで実行する。
  ラベルは後続PR更新にも有効なので、測定確認後に外す。
- 5%/10%等のホスト時間差は警告。閾値だけでビルド・ZIP生成を失敗にしない。
- 計算/文字/描画結果不一致、クラッシュ、測定欠落/破損/不正値、対象SHA不一致、容量制約違反は必須検査の失敗。
- 未測定はNOT_RUN、測定異常はERRORとして記録し、PASSにしない。
- ホスト測定でPicoCalc実機の性能を断定しない。実機で再現する退行は別途条件を揃えて評価する。
- [CI / Performance](../development/ci-build-performance.md) の操作・状態定義・証跡配置を参照する。


- 同一内容に対して不要なrelease専用full CIを重複実行しない。
- Manual再生成・hash・目視QAは[Manual generation](../development/manual-pdf-generation.md)に従う。
- merge / squash等で正式リリース元SHAが変わった場合は、最終commitに対応するCIを優先する。
- 旧branch headのartifactを使う場合は、最終release sourceとtree内容が同一であることを確認できる場合に限る。

## 4. Build artifact の正本

現行 `.github/workflows/build.yml` は、Versionとbuild番号を含むartifact名を生成する。

例:

```text
CPokecombasic-v0.94-build<run>-pico2w
```

正式リリースでは、**成功済みCI runが生成したGitHub Actions artifact ZIPを完全パッケージの正本として扱う。**

現行artifactは概ね次の構造を持つ。

```text
build/
  CPokecombasic.uf2
  memory-report.txt
  memory-*.txt / *.md
  firmware-manifest.json / stability-evidence.json / package-audit.json
flash-cpb.cmd
examples/
  *.bas
  RMBASIC.CFG
```

v0.94以降の通常配布ZIPにはdebug ELF／map、実験・recovery firmware、中間object、別ZIPを含めない。これらはCI workspaceの開発用資料として扱う。元のActions ZIPを1回展開し、`python tools/validate_release_package.py <ZIPまたは展開directory>`で配置・全hashを検証する。

Versionにより内部構成が変わることがあるため、release前に実際のartifactを確認する。

## 5. 【重要】flash-cpb.cmd の配布ルール

`flash-cpb.cmd` は **GitHub Release の単独assetとして配布しない。**

必ず、成功済みbuildの **GitHub Actions artifact ZIPの中に含めた状態で提供する。**

`flash-cpb.cmd` は引数なしで実行した場合、artifact内の相対パス:

```text
build\CPokecombasic.uf2
```

を使用するため、scriptだけを単独配布するとUF2との対応関係や配置が崩れやすい。

### 必須ルール

- **禁止:** `flash-cpb.cmd` をRelease assetとして単独uploadする。
- **必須:** build artifact ZIP 内の `flash-cpb.cmd` と `build/CPokecombasic.uf2` の相対配置を維持する。
- **推奨:** CIから取得したartifact ZIPを不要に再構成せず、そのまま完全パッケージとしてRelease assetに使用する。
- standalone UF2を併設する場合も、`flash-cpb.cmd` はartifact ZIP内だけに置く。
- public repositoryのsource treeに `flash-cpb.cmd` を含めることと、GitHub Releaseで単独asset配布することは別扱いとする。

## 6. 公開用リポジトリへの反映

development repository で確定した公開対象を public repository に反映する。

確認事項:

- sourceが正式リリース元の内容と一致している。
- README、manual、PDF、release notes、examplesのVersionが一致している。
- public repositoryへ不要なdevelopment専用設定を持ち込んでいない。
- 公開用 `main` の差分を確認してからrelease tagを作成する。

既存のtag命名規則を維持する。

例:

```text
Version 0.90 -> v0.90.0
Version 0.91 -> v0.91.0
```

## 7. GitHub Release asset の構成

### 標準asset

1. **完全build artifact ZIP**
   - verified CI runから取得する。
   - Version / build番号 / pico2wをartifact名で識別できること。
   - `flash-cpb.cmd` はこのZIP内に含む。

2. **通常版 UF2**
   - `Cala-Pokecom-BASIC-v<version>-pico2w.uf2`
   - verified artifact内の `build/CPokecombasic.uf2` と同一内容であること。

3. **正式マニュアルPDF**
   - 現行構成に従い、Install / System / Programming Reference等を添付する。

4. **SHA256SUMS.txt**
   - 完全build artifact ZIP、standalone UF2、PDF等の主要assetのSHA-256を記録する。

### 必要に応じて

- examples専用ZIP
- その他、そのVersionで一般利用者に必要な資料

### 原則として単独公開しないもの

- `flash-cpb.cmd`
- `CPokecombasic-editor-perf.uf2`（診断目的で明示的に必要な場合を除く）
- `.elf`, `.map`, intermediate object（v0.94以降は完全build artifact ZIPからも除外する。memory／test evidenceは同梱可）
- 異なるCI runやlocal buildから混在させた成果物

## 8. Release notes

GitHub Release本文は development repository のrelease notesを基準に作成する。

原則として次を含める。

- Version概要
- 主な新機能 / 改善
- Compatibility / Installation
- Known limitations
- migration注意事項
- Release provenance
  - development repository
  - release source commit SHA
  - verified CI run
  - artifact名
- Release assets一覧

asset一覧には `flash-cpb.cmd` を単独項目として記載しない。

説明が必要な場合は次のように記載する。

```text
Windows one-click updater (flash-cpb.cmd) is included in the complete build artifact ZIP.
```

## 9. Release前チェック

- [ ] public repositoryのsourceが対象Versionである
- [ ] tagが正しいcommitを指している
- [ ] release title / notesのVersionが正しい
- [ ] verified CI artifact ZIPを使用している
- [ ] artifact ZIP内に `flash-cpb.cmd` がある
- [ ] artifact ZIP内に `build/CPokecombasic.uf2` がある
- [ ] ZIP内の相対directory構造が維持されている
- [ ] `flash-cpb.cmd` を単独Release assetとしてuploadしていない
- [ ] standalone UF2がverified artifactのUF2と同一である
- [ ] PDFが最新版である
- [ ] SHA256SUMS.txtがassetと一致している
- [ ] Known limitationsが最新である
- [ ] draft / prerelease設定が意図どおりである

## 10. Publish後チェック

- 完全build artifact ZIPをRelease pageからdownloadできる。
- ZIPを展開すると `flash-cpb.cmd` と `build/CPokecombasic.uf2` が所定位置にある。
- standalone UF2をdownloadできる。
- manual PDFを開ける。
- SHA256が一致する。
- Release pageに不要な単独 `flash-cpb.cmd` が存在しない。
- README / Release notes / asset名のVersion表記が一致する。

可能であれば、公開ZIPを別directoryへ展開し、Windowsで `flash-cpb.cmd` が `build\CPokecombasic.uf2` を検出できることをrelease smoke testとして確認する。

## 11. Release record

| 項目 | 記録 |
|---|---|
| Version | |
| Development release source commit | |
| Verified GitHub Actions run | |
| Build artifact name | |
| Build artifact ZIP SHA-256 | |
| Standalone UF2 SHA-256 | |
| Public repository commit | |
| Release tag | |
| Release URL | |
| Hardware verification | PASS / HOLD |
| Release date | |

## 12. 過去リリースからの注意点

今後の正式リリースでは、`flash-cpb.cmd` を単独Release assetとして置かない。

**build artifact ZIPを完全パッケージとして公開し、その中に `flash-cpb.cmd` を含める。**

この項目は今後のrelease作業で必ず確認する。


## 13. private → publicの具体的な実行手順

公開作業はsource同期・PR統合・tag・正式Release・検証までを含む。開発元と公開先は§1の2リポジトリであり、公開用mainの既存履歴を維持する。

### 13.1 正式sourceと実機受入を固定する

1. development mainのSHA、Version、成功build run、artifact ID、ZIP digest/sizeをGitHubから取得する。過去の会話・branch名だけで選ばない。
2. 最終実機受入のコメントURL、日時、候補sourceとbuildを対応付ける。古いchecklistと後日の承認が競合したら、承認証跡を確認して現行recordを修正する。個別の測定値を推測しない。
3. 文書だけの変更後に新buildを公開する場合、受入候補のCMakeLists / src / include / third_partyとPico SDKが完全一致することを検査する。別の製品変更へ承認を引き継がない。公開binaryの新しい実機測定を実施したとは記録しない。
4. `docs/release/v<version>-hardware-acceptance.json`にUSER_ACCEPTED、証拠URL、受入SHA/build、SDK、product blob一覧を保存する。manifest生成器はpath集合・blob・SDK一致を確認した場合だけ承認を継承し、それ以外はPENDINGを維持する。
5. README / manual / Release notesの古いRC文言を更新し、PDFを再生成する。実際にsourceやPDFが変わった場合のみ新CIを実行し、正式source SHAと新ZIPを対応させる。
6. 性能は受入候補のFULL/reportを参照する。製品ソース不変の文書公開で同じ比較を繰り返さず、新buildのoff/NOT_RUNをPASSへ書き換えない。

### 13.2 原本Actions ZIPの取得・監査

```sh
# ghが使える端末の例。値は成功runから取得する。
gh api repos/CalaMaclir/RetroMiniBASIC-PicoCalc/actions/runs/RUN_ID/artifacts
gh api repos/CalaMaclir/RetroMiniBASIC-PicoCalc/actions/artifacts/ARTIFACT_ID/zip > original-package.zip
python3 tools/validate_release_package.py original-package.zip
sha256sum original-package.zip
```

WorkではGitHub connectorのartifact取得を使ってよい。`gh run download`は展開するので原本ZIP取得の代用にしない。APIのdigest/size、ZIP CRC、重複entry・path traversal、全package-audit hash、UF2、JUnit、manual source/PDFを照合する。別directoryへ1回展開し、同じvalidatorで再検査する。

原本ZIPを再構成・再ZIPしない。生成後に承認された場合、古いRC/受入表示は生成時の履歴として保持し、後日の受入recordを別途対応付ける。新しい公開buildは最新recordを検査してmanifestへ記録する。

### 13.3 公開sourceのallowlistと意図的な差分

publicの現在main・LICENSE・SECURITY・過去Release/tagを出発点とする。private commitをpublicのparentへ追加せず、private branchを丸ごとmerge/mirrorしない。

| 対象 | 公開方針 |
|---|---|
| CMakeLists、src、include、third_party、SDK import、flash-cpb.cmd | 正式development sourceのblobをそのまま同期 |
| examples、host tests、stub、必要なcorrectness tools | 公開sourceからbuild/testできる範囲を同期。private CI topologyは説明済みadaptationで区別 |
| README ja/en、manual index、current source/PDF、manifest、license notice | 公開先リンク・正式Versionを揃え、PDF/source/generator hashは正式buildと一致 |
| Release notes、limitations、受入record、publication record | 導入・互換性・provenanceに必要な内容を公開 |
| private CI・local runner・内部手順・Archive policies・調査報告・private Git履歴 | 新規に無差別コピーしない |
| 既にpublicにある歴史資料 | 原則保持し、現行案内で旧仕様を現在の規則と扱わない |

`docs/release/v<version>-public-source-manifest.json`にdevelopment source、tag、path、development/public blob、adaptationの有無と理由を保存する。rootのREADMEを内部規約で肥大化させない。

Git Data APIならblob → tree → commit → branchの順で公開用treeを作成する。publicの前回commitをparentとする`release/v<version>`とPRを作り、公開対象の全blobを検査する。mainをforce pushしない。検査後にexpected head SHAを指定してPRをmergeする。

### 13.4 公開側の準備・CI

公開repositoryの`tools/publish_release.py prepare`と`.github/workflows/publish-release.yml`を使用する。`docs/release/current-publication.json`はVersion、source、正式run/build、artifact、原本ZIP hash/sizeと入力pathを固定する。sourceのblob manifestは別ファイルへ分離する。

public GITHUB_TOKENではprivate artifactを取得しない。公開承認済みの原本ZIPだけを`.github/release-inputs/`へbyte-for-byteで置く方法を利用できる。この入力は公開配布物であり、secret・内部ログを入れず、期限付きURLや外部credentialをpublic sourceへ保存しない。同一原本でCIを再実行できる。Versionを重ねる際はgit容量を評価し、公開済みassetの再利用方式へ移行しても固定digestを必須とする。

prepareではsource blob、現行Markdown link、ZIP provenance/package hash、UF2 magic、JUnit、manual manifest、hardware source matchを検査し、通常UF2・PDF3冊・SHA256SUMS・Release本文・auditを生成する。公開host regressionは公開sourceから実行する。private専用topologyを公開workflow成功と混同せず、snapshot adaptationまたはN/Aの扱いを記録する。

branch/PR/workflow_dispatchはprepareのみ。publishはprotected public mainへのpushでprepare成功後に限定し、job-level `contents: write`とGITHUB_TOKENを使用する。権限拒否は具体的な設定を報告し、tokenをsourceへ埋め込まない。

### 13.5 Draft Releaseから正式公開へ

1. source監査、公開test、原本package監査を成功させる。
2. public mainとprepare receiptのSHA一致を確認する。
3. 既存tag/Releaseを確認し、異なるcommitの同名tagや公開済みbinaryを上書きしない。
4. 正しい公開commitをtargetとするDraft Releaseを作る。tagは`v<version>.0`規則を維持する。
5. 原本ZIP、通常UF2、PDF3冊、SHA256SUMSをuploadし、名前・size・GitHub digestを照合する。flash-cpb.cmd単独assetは禁止。
6. Draftのassetが過不足なく揃ったらdraft=false、prerelease=falseで公開し、最新正式版に指定する。
7. tag commit、provenance、全public downloadのsize/hashを検証する。

### 13.6 公開後検証・記録

Releaseから全assetを再downloadし、size/SHA256、ZIP CRC・1回展開・updater相対配置・UF2・PDFを再確認する。asset digestだけでdownload検証を代用しない。Windows書込み未実施なら配置PASSとWindows書込みNOT_RUNを分ける。

`publication-audit.json`へpublic/tag commit、development source、run/artifact、受入候補、assets/hash/検証結果を保存し、Actions receipt artifactへ残す。開発側のVersion別publication recordへ公開URLと主要hashを保存する。動的証跡だけの更新でFirmwareを再buildしない。

### 13.7 失敗時の再開

| 停止点 | 再開方法 |
|---|---|
| ZIP/digest/source audit失敗 | 公開せず正式runと取得物を確認。同じVersionの別binaryへ無断切替えしない |
| branch検証失敗 | source/adaptationを修正し新headで検証。製品testを無効化しない |
| mainが進んだ | 差分を確認。古いreceiptを新commitのものとして使わない |
| Draft assetの途中upload | target/sourceと既存digest一致を確認し、同一内容の不足分だけupload |
| 公開済みReleaseあり | 全hash/tag/source一致なら再検証のみ。異なれば新Versionまたは明示的修正方針を決める |
| 公開後download不整合 | 成功を報告せずreceiptを保存。binary/tagを黙って差し替えない |

完了条件はpublic source統合、tag/Release公開、全download hash/package検査、開発側手順とVersion記録の保存が揃うこと。


### 13.9 SDK実体の確認

Version名だけで受入を継承しない。firmware-manifestはCMakeCacheのPICO_SDK_PATHから実際のSDK commit、再帰submodule SHA、dirty/untracked/未初期化状態を読み、受入recordの固定tag 2.3.1（079c6f39023649b154152db30f1d781e884879bc）のgitlinksと照合する。不一致はrelease_ready=falseで正式公開を止める。元候補のmanifestはSDK名のみを記録していたため、公開buildの実体確認を新たに行う。これは新しい実機受入結果ではない。
