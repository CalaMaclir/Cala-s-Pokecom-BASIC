# Cala's Pokecom BASIC Version 0.94 日本語マニュアル

v0.94の正式マニュアルは用途別に3冊へ分かれています。PDFには埋込み日本語font、目次、PDF outline、header／footer、page numberを含みます。

| 文書 | 内容 | PDF |
|---|---|---|
| [導入マニュアル](install-manual-ja.md) | 対応機種、完全artifact ZIP、BOOTSEL、flash-cpb.cmd、更新・復旧 | [v0.94 PDF](Cala-Pokecom-BASIC-v0.94-Install-Manual-ja.pdf) |
| [システムマニュアル](system-manual-ja.md) | Editor 3、Program Storage、USB、STANDBY、keyboard診断、5件Wi-Fi profile | [v0.94 PDF](Cala-Pokecom-BASIC-v0.94-System-Manual-ja.pdf) |
| [プログラミング・リファレンス](programming-reference-ja.md) | Classic／Structured、各commandの対応枠・例・期待結果、Quick Reference | [v0.94 PDF](Cala-Pokecom-BASIC-v0.94-Programming-Reference-ja.pdf) |
| [v0.94 リリースノート](release/v0.94-release-notes.md) | 主要機能、互換性、導入、provenance | - |
| [v0.94 制限事項](release/v0.94-known-limitations.md) | 型、精度、mode差、非対応構文・機能 | - |
| [v0.94 リリース確認](release/v0.94-release-checklist.md) | RCと正式公開の確認項目 | - |

製品名は **Cala's Pokecom BASIC System**、略称は **CPB** です。v0.94でも行番号付きClassic BASICを継続し、行番号なしStructured BASICを追加選択できます。

PDFと原稿のSHA-256は[生成manifest](manuals-manifest.json)へ記録します。公開済みv0.92 PDFとarchive sourceはhistorical artifactとして変更しません。

最終Smoke Testと長時間実機試験の状況は[Release checklist](release/v0.94-release-checklist.md)と[Historical Stage 10-11検証](development/archive/v0.94/v0.94-stage10-11-stability-release.md)へ記録します。
