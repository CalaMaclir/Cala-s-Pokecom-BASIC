### Host regression performance

- Status: **success**
- Compiler jobs: 2; test jobs: 1 (serial)
- Registered / executed tests: 72 / 72
- configure: 2.197 s
- compile_and_link: 240.124 s
- test_execution: 19.635 s
- Total: 262.690 s
- Host cache hit: 51.25%
- Host cache counters (this invocation): `{'direct_cache_hit': 138, 'preprocessed_cache_hit': 47, 'cache_miss': 176, 'called_for_link': 0, 'multiple_source_files': 0}`
